<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... (head content) ... -->
</head>
<body>
    <?php include('includes/header.php'); ?>

    <!-- 1st Banner section -->
    <section class="banner">
        <div class="banner-content">
        <img src="assets/images/banner/banner1.png" alt="Welcome to CarsDekho">
            <h1>Welcome to CarsDekho</h1>
            <p>Your source for the latest car reviews and information.</p>
            <a href="about.php">Learn More</a>
        </div>
    </section>

    <!-- The most searched car section -->
    <section class="most-searched">
        <div class="most-searched-content">
            <h2>Most Searched Cars</h2>
            <ul>
                <li>
                    <img src="assets/images/car/b1.jpeg" alt="Car 1">
                    <a href="car-details.php?id=1">Car 1</a>
                </li>
                <li>
                    <img src="assets/images/car2.jpg" alt="Car 2">
                    <a href="car-details.php?id=2">Car 2</a>
                </li>
                <!-- Add more cars as needed -->
            </ul>
        </div>
    </section>

    <!-- Latest car section -->
    <section class="latest-cars">
        <div class="latest-cars-content">
            <h2>Latest Cars</h2>
            <ul>
                <li>
                    <img src="assets/images/car3.jpg" alt="Car 3">
                    <a href="car-details.php?id=3">Car 3</a>
                </li>
                <li>
                    <img src="assets/images/car4.jpg" alt="Car 4">
                    <a href="car-details.php?id=4">Car 4</a>
                </li>
                <!-- Add more cars as needed -->
            </ul>
        </div>
    </section>

    <?php include('includes/footer.php'); ?>
</body>
</html>
