<?php
// Simulated admin credentials (for demonstration purposes)
$adminUsername = "admin";
$adminPassword = "password";

// Get user-provided credentials from the login form
$userUsername = $_POST['username'];
$userPassword = $_POST['password'];

// Check if provided credentials match admin credentials
if ($userUsername === $adminUsername && $userPassword === $adminPassword) {
    // Authentication successful; set a session variable to indicate admin is logged in
    session_start();
    $_SESSION['admin_logged_in'] = true;

    // Redirect to the admin panel
    header("Location: index.php");
    exit;
} else {
    // Authentication failed; redirect back to the login page with an error message
    header("Location: login.php?error=1");
    exit;
}
?>
