<footer>
    <div class="footer-content">
        <div class="footer-logo">
            <a href="index.php">
                <img src="assets/images/logo.png" alt="CarsDekho Logo">
            </a>
        </div>
        <div class="footer-links">
            <ul>
                <li><a href="about.php">About Us</a></li>
                <li><a href="cars.php">Cars</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="footer-social">
            <ul>
                <li><a href="#"><img src="assets/images/facebook-icon.png" alt="Facebook"></a></li>
                <li><a href="#"><img src="assets/images/twitter-icon.png" alt="Twitter"></a></li>
                <li><a href="#"><img src="assets/images/instagram-icon.png" alt="Instagram"></a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> CarsDekho. All Rights Reserved.</p>
    </div>
</footer>
</body>
</html>
