<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/script.js"></script>
    <title>CarsDekho</title>
</head>
<body>
<header>
    <nav>
        <div id="menu-button" class="menu-icon">&#9776;</div>
        <ul id="main-nav" class="nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="cars.php">Cars</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </nav>
    <div class="logo">
        <a href="index.php">
            <img src="assets/images/logo.png" alt="CarsDekho Logo">
        </a>
    </div>
</header>
