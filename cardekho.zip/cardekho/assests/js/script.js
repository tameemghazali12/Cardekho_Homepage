// Function to toggle the responsive navigation menu
function toggleNav() {
    var nav = document.getElementById("main-nav");
    if (nav.className === "nav") {
        nav.className += " responsive";
    } else {
        nav.className = "nav";
    }
}

// Attach the toggleNav function to a button or icon for mobile devices
var menuButton = document.getElementById("menu-button");
if (menuButton) {
    menuButton.addEventListener("click", toggleNav);
}
